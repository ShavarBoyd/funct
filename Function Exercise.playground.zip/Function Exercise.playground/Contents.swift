func Addition () {
    let a = 4
    let b = 9
    let c = a + b
    print (c)
}
Addition()



func addtwo (a: Int, b:Int) -> Int {
    var sum = 0
    sum = a + b
    
    return sum
}

var a = 100
var b = 140

func plus (min: Int, max: Int) -> Int {
    let a = 100
    let b = 400
    return a + b
}
print(plus(min:a, max: b))
